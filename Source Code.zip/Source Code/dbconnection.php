<?php
$con = mysqli_connect("localhost","root","","supermarket");
echo mysqli_connect_error();
?>